package Utils;

public enum ActionVillageois {
    normal, attack, walkAttack
}
