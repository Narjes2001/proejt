package Utils;

public enum Direction {
    up, down, right, left
}
