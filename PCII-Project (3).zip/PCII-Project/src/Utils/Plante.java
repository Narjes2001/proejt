package Utils;

public enum Plante {
    carotte, tomate, pommeDeTerre
}
