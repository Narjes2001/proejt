package Utils;

public enum Vie {
    vivant, mort
}
